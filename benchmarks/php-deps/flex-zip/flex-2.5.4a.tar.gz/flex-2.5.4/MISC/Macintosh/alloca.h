/****************
** alloca.h
**
** header for alloca()
*****************/

typedef void *pointer;

pointer alloca(unsigned size);

