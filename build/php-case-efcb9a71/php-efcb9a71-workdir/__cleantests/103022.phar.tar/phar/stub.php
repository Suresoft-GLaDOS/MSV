<?php echo "first stub\n"; __HALT_COMPILER(); ?>
