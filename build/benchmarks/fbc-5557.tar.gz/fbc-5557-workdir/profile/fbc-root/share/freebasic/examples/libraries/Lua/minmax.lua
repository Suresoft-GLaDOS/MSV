-- Show how to call a function registered in the embedding application
-- MinMax is a FB function

Min, Max = MinMax(42, 2, 17, 33, 15, 1.5)

print("Lua: Min= ", Min, ", Max= ", Max, "\n")

