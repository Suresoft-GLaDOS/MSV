#include <stdio.h>
#include <wchar.h>

int swprintf(FILE *stream, const wchar_t *format, ...)
{
  return 0;
}
